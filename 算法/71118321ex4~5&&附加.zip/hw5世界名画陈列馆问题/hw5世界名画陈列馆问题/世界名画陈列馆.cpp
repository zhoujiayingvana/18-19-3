#include<iostream>
#include<fstream>
using namespace std;

int m, n, best;
bool **loc;//��¼������λ��
int **motr;//��¼���񱻼��״̬
bool **bestx;//��¼���Ž�
int rcount = 0, gridcount = 0;//rcount��¼���û���������,gridcount��¼�ѱ����ӵķ�������
int dx[5] = { 0,1,-1,0,0 }, dy[5] = { 0,0,0,1,-1 };

void set(int i, int j)
{
	rcount++;
	loc[i][j] = 1;//���û�����
					   //�ı��������Χ�ļ��״̬
	for (int k = 0; k < 5; k++)
	{
		motr[i + dx[k]][j + dy[k]]++;
		if (motr[i + dx[k]][j + dy[k]] == 1)
			gridcount++;
	}
}

void reset(int i, int j)
{
	rcount--;
	loc[i][j] = 0;//���û�����
					   //�ı��������Χ�ļ��״̬
	for (int k = 0; k < 5; k++)
	{
		motr[i + dx[k]][j + dy[k]]--;
		if (motr[i + dx[k]][j + dy[k]] == 0)
			gridcount--;
	}
}

void search(int i, int j)
{
	while (motr[i][j] && i <= m)
	{
		j++;
		if (j > n)
		{
			i++;
			j = 1;
		}
	}
	if (i > m)
	{
		if (rcount < best)
		{
			best = rcount;
			for (int i = 1; i <= m; i++)
				for (int j = 1; j <= n; j++)
					bestx[i][j] = loc[i][j];
		}
		return;
	}
	if ((m*n + 4 - gridcount) / 5 + rcount >= best)
		return;
	if (j < n&&motr[i][j + 1] == 0)
	{
		set(i, j + 1);
		search(i, j);
		reset(i, j + 1);
	}
	if (i < m && (motr[i + 1][j] == 0 || motr[i + 2][j] == 0))
	{
		set(i + 1, j);
		search(i, j);
		reset(i + 1, j);
	}
	if (motr[i + 1][j] == 0 && motr[i][j + 1] == 0)
	{
		set(i, j);
		search(i, j);
		reset(i, j);
	}
}

int main() {
	ifstream input("input.txt");
	ofstream output("output.txt");
	
	input >> m >> n;
	best = m * n;
	loc = new bool*[m + 2];//�������䷽��
	motr = new int*[m + 2];
	bestx = new bool*[m + 2];
	for (int i = 0; i <= m + 1; i++)
	{
		loc[i] = new bool[n + 2];
		motr[i] = new int[n + 2];
		bestx[i] = new bool[n + 2];
		fill(loc[i], loc[i] + m + 2, 0);
		fill(motr[i], motr[i] + m + 2, 0);
		fill(bestx[i], bestx[i] + m + 2, 0);
	}
	search(1, 1);
	output << best << endl;
	for (int i = 1; i <= m; i++)
	{
		for (int j = 1; j <= n; j++)
			output << bestx[i][j] << ' ';
		output << endl;
	}
	input.close();
	output.close();
	return 0;
}