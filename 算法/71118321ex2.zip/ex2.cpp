#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

template<typename T>
void SWAP(T * a, T * b)
{
	T t;
	t = *a;
	*a = *b;
	*b = t;
}

int Ordinal(int len, vector<int> &dictionary, int factorial[])
{
	int  ordinal = 0;
	for (int i = 0, k = len - 1; i < len - 1; i++, k--)
	{
		int before = 0;
		for (int j = 0; j < i; j++)
			if (dictionary[j] < dictionary[i])
				before++;
		ordinal += (dictionary[i] - 1 - before)*factorial[k];
	}
	return ordinal;
}

void NextOrder(int len, vector<int> &dictionary)
{
	int h;
	for (int i = len - 2; i >= 0; i--)
	{
		if (dictionary[i] < dictionary[i + 1])
		{
			int j = i;
			for (int k = len - 1; k > j; k--)
			{
				if (dictionary[k] > dictionary[i])
				{
					int mid = j + (len - j) / 2;
					SWAP(&dictionary[j], &dictionary[k]);
					for (j++, h = 1; j <= mid; j++, h++)
						SWAP(&dictionary[j], &dictionary[len - h]);
				}
			}
			break;
		}
	}
}

int main()
{
	ifstream input("input.txt");
	ofstream output("output.txt");

	int factorial[20] = { 0 };

	char length;
	if (!input.is_open())
	{
		cout << "Error opening file!" << endl;
		exit(1);
	}
	int len;
	input >> len;
	input.seekg(3);

	int count = 0;
	vector<int> dictionary;
	dictionary.reserve(20);
	int num;
	while (input >> num)
		dictionary.push_back(num);
	//Use arrays to record the factorial values of a given length in advance to avoid the overhead of function calls.
	factorial[0] = 1;
	for (int i = 1; i <= len; i++)
		factorial[i] = factorial[i - 1] * i;
	if (len == 1)
		output << dictionary[0];
	else if (len >= 2)
	{
		int ordinal = Ordinal(len, dictionary, factorial);
		output << ordinal << "\n";

		NextOrder(len, dictionary);

		for (int i = 0; i < len; i++)
			output << dictionary[i] << " ";
	}

	input.close();
	output.close();

	return 0;
}