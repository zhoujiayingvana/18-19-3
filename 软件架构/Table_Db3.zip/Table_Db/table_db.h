﻿#ifndef TABLE_DB_H
#define TABLE_DB_H

#include <QWidget>
#include <iostream>
#include <vector>
#include <QSqlQuery>
using namespace std;
/**
*功能：菜品信息结构体
*参数：菜名-Name_dish	数量-Num_dish	价格-Price_dish
**/
struct DishesInfo
{
    char* Name_dish;
    int Num_dish;
    double Price_dish;
    DishesInfo()
    {
        Name_dish = new char[10];
        Num_dish = 0;
        fill(Name_dish,Name_dish+10,0);
    }
    DishesInfo(const DishesInfo& t){
        this->Name_dish =new char[10];
        strcpy(Name_dish,t.Name_dish);
        this->Num_dish=t.Num_dish;
        this->Price_dish=t.Price_dish;
    }
    ~DishesInfo(){
        if(Name_dish)
            delete[]Name_dish;
    }
};

class Table_Db : public QWidget
{
    Q_OBJECT

public:
    Table_Db(QWidget *parent = 0);
    ~Table_Db();
    /**
    *功能：连接数据库
    *参数：主机-用户名-密码-数据库名
    *返回值：1-成功	0-失败
    **/
    bool ConnectDB_Table(const char* host, const char* usr, const char* pswd, const char* name_db);

    /**
    *功能：增加，实时提交所点菜品
    *参数：菜品名称，餐桌号
    *返回值：1-成功 0-插入失败
    **/
    bool Add_Table(char* dish, int tableNum);

    /**
    *功能：当前菜品批量加入当日流水
    *参数：餐桌号
    *返回值：1-成功 0-添加失败
    **/
    //bool AddToSeq_Table(char* dish, int tableNum);


    /**
    *功能：删除一道菜
    *参数：菜品名，餐桌号
    *返回值：1-成功	0-失败
    **/
    bool Delete_Table(char*dicsh, int tableNum);

    /**
    *功能：查看订单
    *参数：餐桌号_tableNum
    *返回值：返回vector
    **/
    vector<DishesInfo> Show_Table(int tableNum);


    /**
    *功能：断开数据库
    *参数：void
    *返回值：void
    **/
    void FreeDb_Table(void);


    /**
    *功能：清空
    *参数：餐桌号-tableNum
    *返回值：1-清空成功	0-清空失败
    **/
    bool Clear_Table(int tableNum);

    /**
    *功能：计算消费金额
    *参数：餐桌号-tableNum
    *返回值：消费金额 double
    **/
    double TotalBill(int tableNum);

private:
    QSqlDatabase db;
    QString SqlText;
};



#endif // TABLE_DB_H
