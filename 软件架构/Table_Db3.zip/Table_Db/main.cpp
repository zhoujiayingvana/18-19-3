﻿#include "table_db.h"
#include <QApplication>
#include<iostream>
#include"table_db.h"
#include<vector>
#include <QDebug>
/* Main.cpp为测试文件 */
using namespace std;
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Table_Db *tableDb = new Table_Db();
    char *Eng=new char[10];
    char *t=new char[10];
    char *str=new char[10];
    memset(t,0,sizeof(t));
    memset(t,0,sizeof(str));
    memset(Eng,sizeof(Eng),0);
    strcpy(t,"菠萝鸡");
    strcpy(str,"红烧肉");
    const char *host="localhost";
    const char *usr="root";
    const char *pswd="vana720343";
    const char *name_Db="menudb";
    //连接数据库
    if (tableDb->ConnectDB_Table(host, usr, pswd, name_Db))
    {
        //增加数据
        tableDb->Add_Table(str, 1);//使用ADD函数添加数据
        tableDb->Add_Table(t, 1);//中文菜品的可以添加


        //删除数据
        tableDb->Delete_Table(Eng, 1);
        //查询表格
        vector<DishesInfo> show(tableDb->Show_Table(1));
        for(int i=0;i<show.size();i++){
            QString qName=QString::fromLocal8Bit(show[i].Name_dish);//用QString封装数据
            qDebug()<<qName<<' ';
            qDebug()<<show[i].Price_dish<<endl;
            qDebug()<<show[i].Num_dish<<' ';
        }
        //获得订单金额
        double bill =tableDb->TotalBill(1);
        qDebug()<<"The total bill is"<<bill<<endl;
        //清除表格
        //tableDb->Clear_Table(1);
        //断开连接
        tableDb->FreeDb_Table();
    }

    Table_Db w;
    w.show();
    return a.exec();

}
