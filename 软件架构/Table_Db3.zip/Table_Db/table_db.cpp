﻿#pragma execution_character_set("utf-8")
#include "table_db.h"
#include <QSqlDatabase>
#include <QDebug>
#include <QSqlQuery>
#include <QSqlRecord>
#include <cstring>
#include <QTextStream>
#include <QTextCodec>
Table_Db::Table_Db(QWidget *parent)
    : QWidget(parent)
{
}

Table_Db::~Table_Db() {
    /*if (sql) //sql语句
        delete[]sql;
    if(errInfo)//错误信息
        delete[]errInfo;
        */
}

bool Table_Db::ConnectDB_Table(const char* host, const char* usr, const char* pswd, const char* name_db)
{
    /*usr = new char[10];
    pswd = new char[20];
    name_db = new char[10];
    strcpy_s(usr,sizeof("root"),"root");
    strcpy_s(pswd, sizeof("88888888"), "88888888");
    strcpy_s(name_db, sizeof("ordersys"), "ordersys");*/
    db=QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName(host);
    db.setUserName(usr);
    db.setPassword(pswd);
    db.setDatabaseName(name_db);
    if(!db.open()){
        qDebug()<<"Cannot open DB";
        return 0;
    }

    db.exec("SET NAMES utf8");
    /*db.exec("set character_set_client=utf8");//设置编码格式
    db.exec("set character_set_connection=utf8");
    db.exec("set character_set_results=utf8");
    query=QSqlQuery(db);
    QSqlQuery query;
    query.exec("set character_set_client=utf8");//设置编码格式
    query.exec("set character_set_connection=utf8");
    query.exec("set character_set_results=utf8");
    */
    //query.exec("set character_set_server=utf8");
   // query.exec("set character_set_system=utf8");
   // query.exec("set character_set_database=utf8");
                                          /*delete[] usr;
                                          delete[] pswd;
                                          delete[] name_db;*/
    return 1;
}

bool Table_Db::Add_Table(char* dish, int tableNum)
{
    QSqlQuery query(db);
    QString qDish=QString::fromLocal8Bit(dish);//用QString封装数据
    SqlText="select * from menu where Name=:dish";
    query.prepare(SqlText);//从菜单中查找
    query.bindValue(":dish",qDish.toUtf8());
    query.exec();
    if(!query.first()){//查询失败
        //执行query.exec(sql)后，query是指向结果集以外的，我们可以利用query.next()使得 query指向结果集的第一条记录
        qDebug()<<("No such dish.");
        return 0;
    }
    //查询成功
        QString qPrice=query.value(2).toString();//用QString封装菜价
        QString qNum="1";//用QString封装数据
        //插入数据
        SqlText.sprintf("insert into table0%d (SerialNum,Name,Price,Num) values(null,:name, :price, :num)",tableNum);
        query.prepare(SqlText);
        query.bindValue(":name",qDish.toUtf8());
        query.bindValue(":price",qPrice);
        query.bindValue(":num",qNum);
        //
        if(!query.exec()){//插入失败
            qDebug()<<"Failed to insert dishes into table.";
            return 0;
        }
    return 1;//插入成功
}



bool Table_Db::Delete_Table(char*dish, int tableNum)
{
    QSqlQuery query(db);
    QString qDish=QString::fromLocal8Bit(dish);//用QString封装数据
    SqlText.sprintf("DELETE FROM table0%d WHERE Name=:name",tableNum);
    query.prepare(SqlText);
    query.bindValue(":name",qDish);
    if (!query.exec()) {//删除失败
        qDebug()<<"No such dish";
        query.clear();
        return 0;
    }
    //删除成功
    return 1;
}



void Table_Db::FreeDb_Table(void)
{
    db.close();
}

vector<DishesInfo> Table_Db::Show_Table(int tableNum) {
    vector<DishesInfo> dishesInfo;
    DishesInfo temp;
    QSqlQuery query(db);
    SqlText.sprintf("select * from table0%d",tableNum);
    qDebug()<<SqlText<<endl;
    if (!query.exec(SqlText)) {//查询失败
        qDebug()<<"Failed to get the dishes information.";
    }
    else{
        if(!query.next()){//获取结果失败
            qDebug()<<"This table has no dishes.";
        }
        else{//获取结果成功
            QByteArray ba;
            do{
                ba = query.value(1).toString().toLocal8Bit();
                strcpy(temp.Name_dish,ba.data());
                temp.Price_dish = query.value(2).toDouble();
                temp.Num_dish = query.value(3).toInt();
                dishesInfo.push_back(temp);
            }while(query.next());

            }
        }
    return dishesInfo;
}


bool Table_Db::Clear_Table(int tableNum) {
    QSqlQuery query;
    SqlText.sprintf("truncate table table0%d",tableNum);
    query.prepare(SqlText);
    if (!query.exec()) {//执行成功
        return 0;

    }
    qDebug()<<"Failed to clear the table.";
    return 0;
}

double Table_Db::TotalBill(int tableNum){
    QSqlQuery query;
    SqlText.sprintf("select sum(Price) from table0%d",tableNum);
    if(!query.exec(SqlText)){//求和失败
        return 0;
    }
    query.next();
    return query.value(0).toDouble();
}
