﻿#pragma execution_character_set("utf-8")
#include "new_Menu_Db.h"
#include <QDebug>
Menu_Db::Menu_Db(QWidget *parent)
    : QWidget(parent){}
Menu_Db::~Menu_Db() {}
bool Menu_Db::ConnectDB(const char* host,const char* usr,const char* pswd,const char* name_db)
{
    db=QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName(host);                    //连接数据库端口号
    db.setDatabaseName(name_db);          //连接数据库名
    db.setUserName(usr);                //数据库用户名
    db.setPassword(pswd);               //数据库密码
    db.open();
    if(!db.open())
    {
        qDebug()<<"不能连接"<<"connect to mysql error"<<db.lastError().text();
        return 0;
    }
    QSqlQuery qsQuery(db);
    qsQuery=QSqlQuery(db);
    db.exec("SET NAMES utf8"); ///设置utf-8编码
    return 1;
    //表menu不存在则创建
    /*strSqlText = "create table if not exists menu(id int primary key auto_increment,Name varchar(20), Intro varchar(40), Price double)";
    qsQuery.prepare(strSqlText);//创建表时必须指定中文存储格式为utf8，应该修改SQL语句，这里先省略创建表
    qsQuery.exec();
    if (!qsQuery.isActive()) {
        return 0;
    }
    return 1;
    */
}
int Menu_Db::Add(vector<MenuInfo> &Menuinfo)
{
    QSqlQuery qsQuery(db);
    MenuInfo tmp;
    QString qName;
    QString qIntro;
    QString qPrice;
    for (int i = 0; i < Menuinfo.size(); i++)
    {
        if (0 == Verify(Menuinfo[i], tmp))
        {
            qName=QString::fromUtf8(Menuinfo[i].Name_menu);
            qIntro=QString::fromUtf8(Menuinfo[i].Intro_menu);
            qPrice=QString::number(Menuinfo[i].Price_menu,10,5);
            strSqlText = "insert into menu(Name,Intro,Price) values(:Name, :Intro, :Price)";
            qsQuery.prepare(strSqlText);
            qsQuery.bindValue(":Name",qName.toUtf8() );
            qsQuery.bindValue(":Intro", qIntro.toUtf8());
            qsQuery.bindValue(":Price", qPrice.toUtf8());
            qsQuery.exec();
            if (!qsQuery.isActive()) {
                return -1;//插入失败
            }
        }
        else
            return 0;//表中已有重名数据
    }
    return 1;//成功
}

bool Menu_Db::Delete(MenuInfo &Menuinfo)
{
    QSqlQuery qsQuery=QSqlQuery(db);
    strSqlText = "delete from menu where Name=:Name";
    qsQuery.prepare(strSqlText);
    QString qName=QString::fromLocal8Bit(Menuinfo.Name_menu);
    qsQuery.bindValue(":Name", qName);
    qsQuery.exec();

    if (!qsQuery.isActive())
        return 0;//失败
    return 1;
}

int Menu_Db::Verify(MenuInfo &Menuinfo, MenuInfo &ressult)
{
    QSqlQuery qsQuery=QSqlQuery(db);
    QString qName=QString::fromLocal8Bit(Menuinfo.Name_menu);
    strSqlText = "select * from menu where Name=:name";
    qsQuery.prepare(strSqlText);
    qsQuery.bindValue(":name", qName);
    qsQuery.exec();
    if (!qsQuery.isActive()) {
        return -1;//失败
    }

    if (qsQuery.next())  // 结果列数大于0
    {
        ressult.id_menu = qsQuery.value(0).toInt();
        strcpy_s(ressult.Name_menu, 20, qsQuery.value(1).toString().toStdString().c_str());
        strcpy_s(ressult.Intro_menu, 40, qsQuery.value(2).toString().toStdString().c_str());
        ressult.Price_menu = qsQuery.value(3).toDouble();
        return 1;
    }
    else
        return 0;//未搜索到结果
}

bool Menu_Db::ModifyData(MenuInfo &Menuinfo)
{
    QSqlQuery qsQuery=QSqlQuery(db);
    QString qName=QString::fromLocal8Bit(Menuinfo.Name_menu);
    strSqlText = "update menu set Intro='%s',Price=%f WHERE Name=:Name";
    qsQuery.prepare(strSqlText);
    qsQuery.bindValue(":Name", qName);
    qsQuery.exec();
    if (!qsQuery.isActive()) {
        //printf_s(errInfo, 100, mysql_error(&myCont));
        return 0;//失败
    }
    return 1;
}

void Menu_Db::FreeDb(void)
{
    db.close();
}

bool Menu_Db::getMenuList(vector<MenuInfo>&vecMenu)
{
    QSqlQuery qsQuery=QSqlQuery(db);
    strSqlText = "select * from menu";
    qsQuery.prepare(strSqlText);
    qsQuery.exec();
    if (!qsQuery.isActive()) {
        //printf_s(errInfo, 100, mysql_error(&myCont));
        return 0;//失败
    }
    while (qsQuery.next())  // 结果列数大于0
    {
        MenuInfo tmp;
        QByteArray ba,ca;
        ba = qsQuery.value(1).toString().toLocal8Bit();
        ca = qsQuery.value(2).toString().toLocal8Bit();
        tmp.id_menu = qsQuery.value(0).toInt();
        strcpy(tmp.Name_menu,ba.data());
        strcpy(tmp.Name_menu,ca.data());
        tmp.Price_menu = qsQuery.value(3).toDouble();
        vecMenu.push_back(tmp);
    }
    return 1;
}

bool Menu_Db::Clear_Menu() {
    QSqlQuery qsQuery;
    qsQuery.prepare("truncate table menu");
    if (!qsQuery.exec()) {//执行成功
        return 0;

    }
    qDebug()<<"Failed to clear the table.";
    return 0;
}

