﻿#pragma execution_character_set("utf-8")
#ifndef NEW_MENU_DB_H
#define NEW_MENU_DB_H
#include <QWidget>
#include <iostream>
#include <vector>
#include <QCoreApplication>
#include <QSqlError>
#include <QSqlQuery>
#include <QtDebug>
#include <QVector>
using namespace std;
/**
*功能：Menu信息结构体
*参数：id-id_menu  菜名-Name_menu	介绍-Intro_menu	价格-Price_menu
**/
struct MenuInfo
{
    int id_menu;
    char* Name_menu;
    char* Intro_menu;
    double Price_menu;
    MenuInfo()
    {
        Name_menu = new char[20];
        Intro_menu = new char[40];
        fill(Name_menu,Name_menu+20,0);
        fill(Intro_menu,Intro_menu+40,0);
    }
};

class Menu_Db: public QWidget
{
    Q_OBJECT
public:
    Menu_Db(QWidget *parent = 0);
    ~Menu_Db();
    /**
    *功能：连接数据库，如果不存在表menu则创建(自动加id 升序)
    *参数：主机-用户名-密码-数据库名
    *返回值：1-成功	0-失败
    **/
    bool ConnectDB(const char* host, const char* usr, const char* pswd, const char* name_db);

    /**
    *功能：增加
    *参数：数据结构体
    *返回值：1-成功	0-表中已有重名数据	-1-插入失败
    **/
    int Add(vector<MenuInfo> &Menuinfo);

    /**
    *功能：删除
    *参数：数据结构体
    *返回值：1-成功	0-失败
    **/
    bool Delete(MenuInfo &Menuinfo);

    /**
    *功能：查询
    *参数：数据结构体-Menuinfo	查询结果-ressult
    *返回值：1-查询到相应结果	0-未查询到	-1-	查询失败
    **/
    int Verify(MenuInfo &Menuinfo, MenuInfo &ressult);

    /**
    *功能：修改
    *参数：数据结构体-Menuinfo
    *返回值：1-成功	0-失败
    **/
    bool ModifyData(MenuInfo &Menuinfo);

    /**
    *功能：断开数据库
    *参数：void
    *返回值：void
    **/
    void FreeDb(void);

    /**
    *功能：获取表格
    *参数：获取结果-vecMenu
    *返回值：0-获取失败	1-获取成功
    **/
    bool getMenuList(vector<MenuInfo>&vecMenu);

    /**
    *功能：清空表格
    *参数：
    *返回值：0-失败	1-成功
    **/
    bool Clear_Menu();
private:
    QSqlDatabase db;
    QString strSqlText;
};

#endif // NEW_MENU_DB_H
