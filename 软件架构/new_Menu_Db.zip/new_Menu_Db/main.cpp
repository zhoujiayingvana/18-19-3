﻿#pragma execution_character_set("utf-8")
#include "new_Menu_Db.h"
#include <QApplication>
int main(int argc,char *argv[])
{

    QApplication a(argc,argv);
    vector<MenuInfo> vec;
    Menu_Db *db=new Menu_Db();

    MenuInfo menutst0;
    strcpy_s(menutst0.Name_menu, 20, "菠萝鸡");
    strcpy_s(menutst0.Intro_menu, 20, "牛逼");
    menutst0.Price_menu = 20.8;
    qDebug()<<"test name"<<QString::fromUtf8(menutst0.Name_menu);
    vec.push_back(menutst0);

    MenuInfo menutst1;
    strcpy_s(menutst1.Name_menu, 20, "黄焖鸡");
    strcpy_s(menutst1.Intro_menu, 20, "good");
    menutst1.Price_menu = 88.8;
    vec.push_back(menutst1);

    MenuInfo menutst2;
    strcpy_s(menutst2.Name_menu, 20, "红烧肉");
    strcpy_s(menutst2.Intro_menu, 20, "奈斯");
    menutst2.Price_menu = 50.9;
    vec.push_back(menutst2);

    MenuInfo menutst3;
    strcpy_s(menutst3.Name_menu, 20, "青椒肉丝");
    strcpy_s(menutst3.Intro_menu, 20, "bravo!");
    menutst3.Price_menu = 200.6;
    vec.push_back(menutst3);


    //连接数据库
    if (db->ConnectDB("localhost", "root", "vana720343", "menudb"))
    {
        //增加数据
        if(db->Add(vec))
            qDebug()<<"Add 成功！\n";
        //删除数据
        //db.Delete(menutst0);
        if(db->Delete(menutst1))
            qDebug()<<"Delete 成功！\n";
        //db.Delete(menutst2);
        // db.Delete(menutst3);
        //查询数据库
         MenuInfo res;
        db->Verify(menutst2,res);
        qDebug()<<"查询结果\n";
        qDebug("%u\t%s\t%s\t%f\n",res.id_menu,res.Name_menu,res.Intro_menu,res.Price_menu);
        //修改数据
        strcpy_s(menutst2.Intro_menu, 20, "wowwwwwwwwwww");
        if(db->ModifyData(menutst2))
            qDebug("ModifyData 成功！\n");
        //获取列表
        vec.clear();
        db->getMenuList(vec);
        qDebug("获取表\n");
        QString qName;
        QString qIntro;
        for (int i = 0; i<vec.size(); i++)
        {

            qDebug("%u\t%s\t%s\t%f\n",vec[i].id_menu, vec[i].Name_menu, vec[i].Intro_menu, vec[i].Price_menu);
        }
        qName=QString::fromLocal8Bit(vec[1].Name_menu);
    }
    else
    {
        qDebug("数据库连接失败\n");
    }

    //清空表格
    //db->Clear_Menu();
    //断开连接
    db->FreeDb();
    MenuInfo tmp;
    if (-1 == db->Verify(menutst1,tmp))
        qDebug("Close db success!" );
    db->show();
    return a.exec();
}
